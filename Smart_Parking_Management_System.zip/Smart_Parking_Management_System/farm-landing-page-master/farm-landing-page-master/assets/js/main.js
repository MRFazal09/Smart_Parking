import navigation from './navigation.js'
import works from './works.js'
import testimonials from './testimonials.js'
navigation();
works();
testimonials();